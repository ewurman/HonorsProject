import DecisionTreePlayer
import battlecode as bc
import random
import sys
import traceback
import time
import os
from copy import copy, deepcopy
from collections import deque




gc = bc.GameController()







''' Need to generate the 5 trees '''


player = DecisionTreePlayer()